class user{
    constructor(id,name,email){
        this.id=id;
        this.name=name;
        this.email=email;
    }

}

let obj1= new user(1,'rushikesh','phanse@gmail.com');

const fs=require('fs');

const savedata=(obj1)=>{
    const finish=(error)=>{

        if(error)
        {
            console.log("error");
            return;
        }

    }
    const usernew=JSON.stringify(obj1);
    console.log(usernew);
    fs.writeFile('user.json',usernew,finish)
   
}
savedata(obj1);
