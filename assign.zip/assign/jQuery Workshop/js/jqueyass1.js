$(document).ready(function(){
    
 
     $('.red').click(function(){
        $('.orange-circle').hide();
        $('.yellow-circle').hide(); 
        $('.red-circle').show();
     });
     
     $('.orange').click(function(){
        $('.red-circle').hide();
        $('.yellow-circle').hide(); 
        $('.orange-circle').show();
     });
     
     
     $('.yellow').click(function(){
        $('.orange-circle').hide();
        $('.red-circle').hide(); 
        $('.yellow-circle').show();
     });
    
     $('.all').click(function(){
         $('.red-circle').show();
        $('.orange-circle').show();
        $('.yellow-circle').show(); 
     });
     
     

 
 
 });
 