
$(document).ready(function(){
   /* $('.fade-In').click(function(){
        $('p').fadeIn();
    });
    $('.fade-Out').click(function(){
        $('p').fadeOut();
    });
    $('.fade-toggle').click(function(){
        $('p').fadeToggle();
    });
*/
    $('.before').click(function(){
     $('p').before('<h1>Before para</h1>');
    });

    $('.after').click(function(){
        $('p').after('<h1>After para</h1>');
       });


});
