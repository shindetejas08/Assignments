class Book{
    constructor(id,name,price){
    this.id=id;
    this.name=name;
    this.price=price;
    }
}
var bookarray=[];  

function addbook()
{
    var id=document.getElementById('bid').value;
    var name=document.getElementById('bname').value;
    var price=document.getElementById('bprice').value;
   
     
  let bookobj=new Book(id,name,price);
  bookarray.push(bookobj);
  sessionStorage.setItem("mybookarray",JSON.stringify(bookarray));
  alert("Book Added Successfully")
  document.getElementById('bid').innerHTML="";
  document.getElementById('bname').innerHTML="";
  document.getElementById('bprice').innerHTML="";
}
console.log(sessionStorage);
console.log(bookarray);

function displaybooklist()
{
 var mynewbookarray=[];
 mynewbookarray=JSON.parse(sessionStorage.getItem("mybookarray"));
 console.log(mynewbookarray);   
var str = '<ul>';
console.log(mynewbookarray);
mynewbookarray.forEach(function(book) {
  str += '<li>'+  book.name  + '</li>';
}); 

str += '</ul>';
document.getElementById("mybooklist").innerHTML = str;
}

function removebook()
 {
     alert("hello");
     console.log("on load");
    var removebookarray=[];
    removebookarray=JSON.parse(sessionStorage.getItem("mybookarray"));
    console.log(removebookarray);   
   var str = '<ul>';
   console.log(removebookarray);
   removebookarray.forEach(function(book) {
     str += '<li>'+  book.name  + '</li> <button id="mybookid">remove</button>'
   }); 
   
   str += '</ul>';
   document.getElementById("mybooklist").innerHTML = str;  
 }
function removebookfromshell(number=id){

}

function deletion(){
    newarray=[];
    str=sessionStorage.getItem("mybookarray");
    newarray=JSON.parse(str);
    
    div= document.getElementById("list");
    
    for(i=0;i<newarray.length;i++)
    {
   console.log(newarray[i].bookname);
    div.innerHTML+=newarray[i].name+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="../HTML/deletedmsg.html?id='+newarray[i].id+'">Delete</a><br>';
   }
}

function deletedbook()
    {
        var obj=new URLSearchParams(window.location.search);
        id=obj.get('id');
        console.log(id);
        arr=[];
        arr=JSON.parse(sessionStorage.getItem("mybookarray"));
        console.log("Before:: "+arr);
        for(i=0;i<arr.length;i++)
        {
            if(arr[i].bookid==id)
            {
                arr.splice(i,1);
            }
        }
            console.log(arr);
        sessionStorage.setItem("mybookarray",JSON.stringify(arr));
        document.getElementById("mydiv").innerHTML="BOOK DELETED!!";
       
      
    }

    function editedbook(){
       
        
        bookid=document.getElementById("bid").value;
        bookname=document.getElementById("bname").value;
        bookprice=document.getElementById("bprice").value;

       bookarray[arrid].bookname=bookname;
       bookarray[arrid].bookprice=bookprice;

        sessionStorage.setItem("mybookarray",JSON.stringify(bookarray));
        location.replace("../HTML/Workshop1.html");
        }


        
function removebook(){
    bookarray.pop();
    console.log(bookarray);
}

function editdetails(){
    newarray=[];
    str=sessionStorage.getItem("mybookarray");
    newarray=JSON.parse(str);
    
    div= document.getElementById("list");
    
    for(i=0;i<newarray.length;i++)
    {
   console.log(newarray[i].bookname);
    div.innerHTML+='<a href="../HTML/editbookdata.html?id='+newarray[i].id+'">'+newarray[i].name+'</a><br>';
   }
}

function getid(){
    var obj=new URLSearchParams(window.location.search);
    id=obj.get('id');
   
   
    bookarray=[];
   bookarray=JSON.parse(sessionStorage.getItem("mybookarray"));
   arrid=0;
   for(i=0;i<bookarray.length;i++)
   {
       if(bookarray[i].bookid==id)
       {
           arrid=i;
       }
   }
   console.log(bookarray[arrid]);
   document.querySelector('[data-model="bid"]').value=bookarray[arrid].id;
    document.querySelector('[data-model="bname"]').value=bookarray[arrid].name;
    document.querySelector('[data-model="bprice"]').value=bookarray[arrid].price;
    }

    function editedbook(){
       
        
        bookid=document.getElementById("bid").value;
        bookname=document.getElementById("bname").value;
        bookprice=document.getElementById("bookprice").value;

       bookarray[arrid].bookname=bookname;
       bookarray[arrid].bookprice=bookprice;

        sessionStorage.setItem("books",JSON.stringify(bookarray));
        location.replace("../HTML/Workshop1.html");
        }

        function deletion(){
            newarray=[];
            str=sessionStorage.getItem("books");
            newarray=JSON.parse(str);
            
            div= document.getElementById("list");
            
            for(i=0;i<newarray.length;i++)
            {
           console.log(newarray[i].bookname);
            div.innerHTML+=newarray[i].bookname+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="../HTML/deletedmsg.html?id='+newarray[i].bookid+'">Delete</a><br>';
           }
        }