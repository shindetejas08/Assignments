# PHP-Calculator
Simple PHP Calculator to use for unit testing
