<?php

class CalculatorTest extends \PHPUnit\Framework\TestCase {
    public function testAdd(){
        $calculator = new App\Calculator;
        $result=$calculator->add(20,30);

        $this->assertEquals(50,$result);
        
    }
    public function testSub(){
        $calculator = new App\Calculator;
        $result=$calculator->subtract(30,20);

        $this->assertEquals(10,$result);
        
    }
    public function testMultiply(){
        $calculator = new App\Calculator;
        $result=$calculator->multiply(20,30);

        $this->assertEquals(600,$result);
        
    }
    public function TestDivide(){
        $calculator = new App\Calculator;
        $result=$calculator->divide(10,2);

        $this->assertEquals(5,$result);
        
    }
    
}

?>