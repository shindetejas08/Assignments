
export class HrLogin{

    hrId!:any;
    firstName!:any;
    lastName!:any;
    fatherName!:any;
    email!:any;
    password!:any;
    role!:any;
    
    constructor(){

    }


}