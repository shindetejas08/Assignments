export class Sallary{
        sallaryid:any;
        basicSalary:any;
        hra:any;
        attendanceAllowance:any;
        medicalAllowance:any;
        bonus:any;
        perDay:any;
        adharno:any;
        panno:any;
        pfno:any;
        accountno:any;
        employee!:{
        empId:any;
     }

     constructor(){
        
}

}