export class Grade{
    // gradeId!:any;
    // grade!:any;
    // basicSalary!:any;
    // hra:any;
    // attendanceAllowance:any;
    // medicalAllowance:any;
    // bonus:any;
    // perDay:any;
    gradeId !: number;
    grade !: string;
    basicSal !: any;
    basicPay !: any;
    medicalAllowance !: any;
    tAttenAllownce !: any;
   
constructor()
{
    


}


}
