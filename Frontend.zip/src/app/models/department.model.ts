export class Department
{
    deptid!:number;
    name!:any;
    constructor(){

    }
}