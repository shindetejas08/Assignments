import { Department } from './department.model';
import {HrLogin} from './hrLogin.model';
import {Grade} from './grade.model';
export class Employee
{
    empId!:any;
    firstName!:any;
    lastName!:any;
    fatherName!:any;
    mobNo!:any;
    dateOfBirth!:any;
    email!:any;
    imageUrl!:any;
    gender!:any;
    joinDate!:any;
    city!:any;
    maritalStatus!:any;
  //belogsToHrId!:HrLogin;
    //belogsToDeptid!:Department;
    //belogsToGradeId!:Grade;
    hr!:{
             hrId:1;
             firstName:string;
             lastName:string;
             fatherName:string;
             email:string;
             password:string;
             role:string;
             
             
    }
    department!:{
      deptid:any;
      name:string;
    }
    grade!:{
      gradeId:any;
      grade:any;
      basicSalary:any;
      hra:any;
      attendanceAllowance:any;
      medicalAllowance:any;
      bonus:any;
      perDay:any;
    }
    sallary!:{
      
        basicSalary:any;
        hra:any;
        attendanceAllowance:any;
        medicalAllowance:any;
        bonus:any;
        perDay:any;
        adharno:any;
        panno:any;
        pfno:any;
        accountno:any;
    }
    constructor(){
        
    }
    
}