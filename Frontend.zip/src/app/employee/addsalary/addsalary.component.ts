import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee/employee.service'
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeModule } from '../employee.module';
import { Employee } from 'src/app/models/employee.model';
import { Sallary } from 'src/app/models/sallary.model';
import { Department } from 'src/app/models/department.model';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addsalary',
  templateUrl: './addsalary.component.html',
  styleUrls: ['./addsalary.component.css']
})
export class AddsalaryComponent implements OnInit {

  email: any;
  employee!: any;
  department!: Department;
  sallary!: any;
  accountNo: any;
  adharNo: any;
  pfNumber: any;
  panNumber: any;

  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.email = this.route.snapshot.params['email'];

    this.employeeService.getEmployeesByEmail(this.email).subscribe(data => {
      this.employee = data;
      console.log("EMployee data" + this.employee);
    })
  }

  book(bookingForm: NgForm) {
    console.log(bookingForm.value);
    var object = {
      "employee": {
        "empId": this.employee.empId
      },
      "basicSalary": this.employee.grade.basicSalary,
      "hra": this.employee.grade.hra,
      "attendanceAllowance": this.employee.grade.attendanceAllowance,
      "medicalAllowance": this.employee.grade.medicalAllowance,
      "bonus": this.employee.grade.bonus,
      "perDay": this.employee.grade.perDay,
      "adharno": bookingForm.controls['accountNo'].value,
      "panno": bookingForm.controls['panNumber'].value,
      "pfno": bookingForm.controls['pfNumber'].value,
      "accountno": bookingForm.controls['accountNo'].value
    };
    console.log(object);
    this.employeeService.createSal(object).subscribe
      (data => {
        this.router.navigate(['/employee/emplyeelist']);
        console.log(data);
        
      }, error => console.log("Error in saving salary"+error)
      )
    // this.router.navigate(['/employee/emplyeelist']);
  }


  //"accountno":this.sallary.accountno,
  onSubmit() {
    this.sallary.basicSalary = this.employee.grade.basicSalary;
    this.sallary.bonus = this.employee.grade.bonus;
    this.sallary.hra = this.employee.grade.hra;
    this.sallary.perDay = this.employee.grade.perDay;
    this.sallary.medicalAllowance = this.employee.grade.medicalAllowance;
    this.sallary.attendanceAllowance = this.employee.grade.attendanceAllowance;
    this.sallary.employee.empId = this.employee.empId;
    console.log()
    console.log(this.sallary);
    debugger;
    var backObject = {
      "basicSalary": this.sallary.basicSalary,
      "bonus": this.sallary.bonus,
      "hra": this.sallary.hra,
      "perDay": this.sallary.perDay,
      "medicalAllowance": this.sallary.medicalAllowance,
      "attendanceAllowance": this.sallary.attendanceAllowance,
      "panno": this.sallary.panno,
      "pfno": this.sallary.pfno,
      "adharno": this.sallary.adharno,

      "employee": {
        "empId": this.sallary.employee.empId,
      }

    };
    this.employeeService.createSal(backObject).subscribe(data => {
      console.log(data);
      this.getEmployees();

    })

  }

  getEmployees() {
    this.router.navigate(['/employees']);
  }

}
