import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee/employee.service'
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/models/employee.model';
import { Department } from 'src/app/models/department.model';
import { Grade } from 'src/app/models/grade.model';
import { NgStyle } from '@angular/common';
import { Sallary } from 'src/app/models/sallary.model';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  employee: Employee = new Employee;

  public departmentlist!: Department[];
  public gradelist!: Grade[];
  selectedepartment!: any;
  departmet!: any;
  hrid!: any;
  msg!: any;
  grade!: any;
  selectedgrade!: any;
  selectedFile!: File;
  message!: string;
  retrievedImage: any;
  sallary!: any;
  imgSrc:any;

  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router,
    private toaster: ToastrService) { }

  ngOnInit(): void {
    this.getTypedepartment();
    this.getAllGrade();
    this.hrById();
  }

  hrById() {
    this.employeeService.getHrBytId().subscribe(data => {
      console.log(data);
      this.hrid = data;
    })
  }

  onOptionsSelected() {
    this.employeeService.getDepartmentId(this.selectedepartment).subscribe(data => {
      this.departmet = data;
    },
      error => {
        this.msg = error.message
      })
  }
  onOptionsSelectedgrade() {
    this.employeeService.getGradeById(this.selectedgrade).subscribe(data => {
      this.grade = data;

    },
      error => {
        this.msg = error.message
      })
  }
  
  public onFileChanged(event: any) {
    console.log(event);
    if (event.target.files && event.target.files[0]) {
      this.selectedFile = event.target.files[0];
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.imgSrc = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
    }
  }


  onSubmit() {
    this.employeeService.createEmployee(this.hrid, this.grade, this.selectedFile, this.departmet, this.employee).subscribe(
      data => {
        debugger;
        console.log("response received")
        console.log(this.employee);
        this.router.navigate(['/addsal', this.employee.email]);
        this.toaster.success("Added employee", "Done!");
      },
      error => {
        console.log("exception occured");
        alert("already exists!!!");
      }
    );
  }

  private getTypedepartment() {
    this.employeeService.getAllDepartment().subscribe(data => {
      console.log(data);
      this.departmentlist = data;
    })
  }


  private getAllGrade() {
    this.employeeService.getAllGrade().subscribe(data => {
      console.log(data);
      this.gradelist = data;

    })
  }







}
