import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmplyeelistComponent } from './emplyeelist/emplyeelist.component';
import { UpdateComponent } from './update/update.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { DeleteemployeeComponent } from './deleteemployee/deleteemployee.component';
import { EmployeeService } from './employee.service';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AddsalaryComponent } from './addsalary/addsalary.component';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@NgModule({
  declarations: [EmplyeelistComponent, UpdateComponent, AddemployeeComponent, DeleteemployeeComponent, AddsalaryComponent, EmployeedetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    BrowserModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),

    
    
  ],
  exports:[
   EmplyeelistComponent,
   UpdateComponent,
   AddemployeeComponent,
   DeleteemployeeComponent,AddsalaryComponent
  ],
  providers: [
    EmployeeService,
  ],
  
})
export class EmployeeModule { }
