import { Component, NgModule, OnInit } from '@angular/core';
import { from, Observable } from 'rxjs';
import { EmployeeService } from './../employee.service'
import { Employee } from 'src/app/models/employee.model';
import { Router } from '@angular/router'
import { FormsModule } from '@angular/forms'
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-emplyeelist',
  templateUrl: './emplyeelist.component.html',
  styleUrls: ['./emplyeelist.component.css']
})

export class EmplyeelistComponent implements OnInit {

  selectedepartment: any;
  department: any;
  msg: any;
  departmentlist: any;
  gradelist: any;
  empId: any;
  displayDetails:any;
  public employees!: Employee[];
  imgType:any;

  constructor(private employeeService: EmployeeService,
    private router: Router,
    private toaster: ToastrService) {

  }


  getById(){
    this.employeeService.getEmployeesById(this.empId).subscribe(data => {
      console.log("EMpData" + data);
      this.displayDetails = data;
      this.imgType = `data:${this.displayDetails.imageContentType};base64,${this.displayDetails.imageurl}`;
    })
  }

  ngOnInit(): void {
    this.getEmployees();
    this.getTypedepartment();
    this.getAllGrade();

  }

  getEmployees() {
    this.employeeService.getEmployeesList().subscribe(data => {
      console.log("EMpData" + data);
      this.employees = data;
    })
  }

  updateEmployee(id: number) {
    this.router.navigate(['update', id]);
  }

  deleteEmployee(id: number) {
    if(confirm("Are you sure you want to delete this employee?")){
      this.employeeService.deleteEmployeeById(id).subscribe(data => {
        console.log(data);
        this.toaster.warning("Deleted employee","Done!");
        this.getEmployees();
      })
    }
    else{
      return;
    }
  }
  onOptionsSelected() {

    this.employeeService.getDepartmentId(this.selectedepartment).subscribe(data => {
      this.department = data;

      this.employeeService.getAllemployeeByDepartment(this.selectedepartment).subscribe(data => {
        this.employees = data;
        console.log(data);
      }, error => {
        this.msg = error.message
        alert("there is no Employee By search department");
      })
    },
      error => {
        this.msg = error.message
      })
  }

  private getTypedepartment() {
    this.employeeService.getAllDepartment().subscribe(data => {
      console.log(data);
      this.departmentlist = data;
    })
  }



  private getAllGrade() {
    this.employeeService.getAllGrade().subscribe(data => {
      console.log(data);
      this.gradelist = data;

    })
  }

}






