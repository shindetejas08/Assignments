import { Injectable, NgModule } from '@angular/core';

import { Observable } from 'rxjs';
import {Employee} from 'src/app/models/employee.model';
import { HttpClient } from '@angular/common/http';
import { Department } from '../models/department.model';
import { Grade } from '../models/grade.model';
import { HrLogin } from '../models/hrLogin.model';
import { Sallary } from '../models/sallary.model';
@Injectable({
  providedIn: 'root'
})

export class EmployeeService {

hrid=1;

  private baseUrl = 'http://localhost:8080/employee';
  private basedept='http://localhost:8080/department';
  private basegrade='http://localhost:8080/grade';
  private basehr='http://localhost:8080/hr';
  private basesal='http://localhost:8080/sallary/addsal';
 constructor(private httpClient: HttpClient) { }




 getEmployeesList(): Observable<Employee[]>{
  return this.httpClient.get<Employee[]>(`${this.baseUrl}`);
}

getEmployeesById(id: number):Observable<Employee[]>{
  return this.httpClient.get<Employee[]>(`${this.baseUrl}/${id}`)
};

getEmployeesByEmail(email: any):Observable<Employee>{
  return this.httpClient.get<Employee>(`${this.baseUrl}/email/${email}`)
};


deleteEmployeeById(id:number):Observable<Object>{
  return this.httpClient.delete(`${this.baseUrl}/${id}`);
}
updateEmployee(updatedobj:Object, id:any):Observable<Object>{
 return this.httpClient.put<Object>(`${this.baseUrl}/${id}`,updatedobj)
}


createEmployee(hrid:HrLogin,grade:Grade,selectedFile:File,department:Department,employee:Employee): Observable<any>{
  const uploadData = new FormData();
  uploadData.append("imageFile",selectedFile);
  console.log(employee);
  uploadData.append("dtls",JSON.stringify(employee));
  console.log(department);
  console.log(grade);
  console.log(hrid);
  console.log(selectedFile);
  uploadData.append("hr",JSON.stringify(hrid));
  uploadData.append("department",JSON.stringify(department));
  uploadData.append("grade",JSON.stringify(grade));
console.log(uploadData);
  
  
  return this.httpClient.post(`${this.baseUrl}/add`,uploadData,{responseType: 'text' });
}

createSal(data: any){
  return this.httpClient.post<any>(`${this.basesal}`,data);
}

getAllDepartment(): Observable<Department[]>{
  return this.httpClient.get<Department[]>(`${this.basedept}`);
}
getAllGrade():Observable<Grade[]>{
  return this.httpClient.get<Grade[]>(`${this.basegrade}`);

}
getDepartmentId(id:number):Observable<Object>{
  return this.httpClient.get<Object>(`${this.basedept}/${id}`);
}
getHrBytId():Observable<Object>{
  return this.httpClient.get<Object>(`${this.basehr}/${this.hrid}`);
}
getGradeById(id:number):Observable<Object>{
  return this.httpClient.get<Object>(`${this.basegrade}/${id}`);
}

getAllemployeeByDepartment(department:number):Observable<Employee[]>{
  return this.httpClient.get<Employee[]>(`${this.baseUrl}/getbydepartmentid/${department}`);
  }
  
}

