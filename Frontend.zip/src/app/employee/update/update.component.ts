import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee/employee.service'
import { ActivatedRoute, Router } from '@angular/router';
import { Department } from 'src/app/models/department.model';
import { Grade } from 'src/app/models/grade.model';
import { Employee } from 'src/app/models/employee.model';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  id: any;
  employee!: any;
  departmentlist!: Department[];
  gradelist!: Grade[];
  selectedgrade!: any;
  selectedepartment!: any;
  departmet!: any;
  grade!: any;
  msg!: any;
  hrid!: any;
  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router,
    private toaster: ToastrService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.employeeService.getEmployeesById(this.id).subscribe(data => {
      console.log("got"+JSON.stringify(data));

      this.employee = data;
      this.employee.imageContentType = `data:${this.employee.imageContentType};base64,${this.employee.imageurl}`;
    })
    this.getTypedepartment();
    this.getAllGrade();

  }

  getEmployees() {
    this.router.navigate(['/employees']);
  }

  book(bookingForm: NgForm) {
    // console.log(bookingForm.value);
    // this.employee.department.deptid = this.departmet.deptid;
    // this.employee.grade.gradeById = this.grade.gradeId;
    // var updateobj = {
    //   "empId": parseInt(this.employee.empId),
    //   "firstName": this.employee.firstName,
    //   "lastName": this.employee.lastName,
    //   "fatherName": this.employee.fatherName,
    //   "age": this.employee.age,
    //   "mobNo": this.employee.mobNo,
    //   "dateOfBirth": this.employee.dateOfBirth,
    //   "email": this.employee.email,
    //   "gender": this.employee.gender,
    //   "imageurl": this.employee.imageurl,
    //   "imageContentType": this.employee.imageContentType,
    //   "joinDate": this.employee.joinDate,
    //   "city": this.employee.city,
    //   "maritalStatus": this.employee.maritalStatus,
    //   "hr": {
    //     "hrId": 1
    //   },
    //   "department": {
    //     "deptid": parseInt(this.employee.department.deptid)
    //   },
    //   "grade": {
    //     "gradeId": parseInt(this.employee.grade.gradeById)
    //   }
    // }

    var temp = {
      "empId": parseInt(this.employee.empId),
      "firstName": this.employee.firstName,
      "lastName": this.employee.lastName,
      "fatherName": this.employee.fatherName,
      "city": this.employee.city,
      "dateOfBirth": this.employee.dateOfBirth,
      "department": {
        "deptid": parseInt(this.employee.department.deptid)
      },
      "gender": this.employee.gender,
      "mobNo": this.employee.mobNo,
      "joinDate": this.employee.joinDate,
      "maritalStatus": this.employee.maritalStatus
    };
    var id = parseInt(this.employee.empId);
    console.log(temp);
    debugger;
    this.employeeService.updateEmployee(temp,id).subscribe(
      data => {
        console.log("response received")
        debugger;
        console.log(data);
        this.toaster.success("Done!","Updated employee")
        this.getEmployees();
      },
      error => {
        console.log("exception occured")
        alert("system not able to update profile")
      }
    )
  }

  // onSubmit() {
  //   this.employee.department.deptid = this.departmet.deptid;
  //   this.employee.grade.gradeById = this.grade.gradeId;
  //   var updateobj = {
  //     "empId": parseInt(this.employee.empId),
  //     "firstName": this.employee.firstName,
  //     "lastName": this.employee.lastName,
  //     "fatherName": this.employee.fatherName,
  //     "age": this.employee.age,
  //     "mobNo": this.employee.mobNo,
  //     "dateOfBirth": this.employee.dateOfBirth,
  //     "email": this.employee.email,
  //     "gender": this.employee.gender,
  //     "imageurl": this.employee.imageurl,
  //     "imageContentType": this.employee.imageContentType,
  //     "joinDate": this.employee.joinDate,
  //     "city": this.employee.city,
  //     "maritalStatus": this.employee.maritalStatus,
  //     "hr": {
  //       "hrId": 1,

  //     },
  //     "department": {
  //       "deptid": parseInt(this.employee.department.deptid),

  //     },
  //     "grade": {
  //       "gradeId": parseInt(this.employee.grade.gradeById),
  //     }
  //   }
  //   console.log(updateobj);
  //   debugger;
  //   this.employeeService.updateEmployee(updateobj).subscribe(
  //     data => {
  //       console.log("response received")
  //       debugger;
  //       console.log(this.employee);

  //       alert("Employee details updated succesfully")

  //       this.getEmployees();
  //     },
  //     error => {
  //       console.log("exception occured")
  //       alert("system not able to update profile")
  //     }
  //   )
  // }


  getTypedepartment() {
    this.employeeService.getAllDepartment().subscribe(data => {
      console.log(data);
      this.departmentlist = data;
    })
  }

  getAllGrade() {
    this.employeeService.getAllGrade().subscribe(data => {
      console.log(data);
      this.gradelist = data;
    })
  }
  onOptionsSelected() {
    this.selectedepartment = this.employee.department.deptid
    console.log(this.selectedepartment)
    this.employeeService.getDepartmentId(this.selectedepartment).subscribe(data => {
      this.departmet = data;
    },
      error => {
        this.msg = error.message
      })
  }
  onOptionsSelectedgrade() {
    this.selectedgrade = this.employee.grade.gradeId;
    console.log(this.selectedgrade);
    this.employeeService.getGradeById(this.selectedgrade).subscribe(data => {
      this.grade = data;

    },
      error => {
        this.msg = error.message
      })
  }




}
