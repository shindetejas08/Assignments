import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
import { EmplyeelistComponent } from './employee/emplyeelist/emplyeelist.component';
import { UpdateComponent } from './employee/update/update.component';
import { AddemployeeComponent } from './employee/addemployee/addemployee.component';
import { HomepageComponent } from './home/homepage/homepage.component';
import { AddsalaryComponent } from './employee/addsalary/addsalary.component';
import { DepartmentlistComponent } from './department/departmentlist/departmentlist.component';
import { AddnewdepartmentComponent } from './department/addnewdepartment/addnewdepartment.component';
import { GradelistComponent } from './grade/gradelist/gradelist.component';
import { AddgradeComponent } from './grade/addgrade/addgrade.component';
import { ExtraworklistComponent } from './extrawork/extraworklist/extraworklist.component';
import { AddextraworkComponent } from './extrawork/addextrawork/addextrawork.component';
import { ListsalaryComponent } from './salary/listsalary/listsalary.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'employee/emplyeelist', component: EmplyeelistComponent, canActivate: [AuthGuard] },
  { path: 'update/:id', component: UpdateComponent, canActivate: [AuthGuard] },
  { path: 'employee/addemployee', component: AddemployeeComponent, canActivate: [AuthGuard] },
  { path: 'home', component: HomepageComponent, canActivate: [AuthGuard] },
  { path: 'addsal/:email', component: AddsalaryComponent, canActivate: [AuthGuard] },
  { path: 'departments', component: DepartmentlistComponent, canActivate: [AuthGuard] },
  { path: 'addnewdepartment', component: AddnewdepartmentComponent, canActivate: [AuthGuard] },
  { path: 'gradelist', component: GradelistComponent, canActivate: [AuthGuard] },
  { path: 'addgrade', component: AddgradeComponent, canActivate: [AuthGuard] },
  { path: 'addextrawork', component: AddextraworkComponent, canActivate: [AuthGuard] },
  { path: 'listextrawork', component: ExtraworklistComponent, canActivate: [AuthGuard] },
  { path: 'listsalary', component: ListsalaryComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
