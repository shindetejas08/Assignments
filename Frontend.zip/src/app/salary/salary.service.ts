import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SalaryService {
  url ="http://localhost:8080/sallary";
  constructor(private httpClient: HttpClient) { }

  getSalary(empid:any, month:any,year:any):Observable<any>{
    return this.httpClient.get<any>(this.url+"/"+empid+"/"+month+"/"+year);
  }

  getAllSalary():Observable<any>{
    return this.httpClient.get<any>(this.url);
  }
}
