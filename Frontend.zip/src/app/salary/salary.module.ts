import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { ListsalaryComponent } from './listsalary/listsalary.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    declarations: [ListsalaryComponent],
    imports: [
      CommonModule,
      FormsModule,
      RouterModule,
      HttpClientModule,
      BrowserModule,
      BrowserAnimationsModule,
      BsDatepickerModule.forRoot(),
    ],
    exports:[
        ListsalaryComponent
    ]
  })
  export class SalaryModule { }
  