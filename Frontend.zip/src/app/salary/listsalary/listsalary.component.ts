import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee/employee.service';
import { SalaryService } from '../salary.service';
import { jsPDF } from "jspdf";
  
import html2canvas from 'html2canvas'; 
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-listsalary',
  templateUrl: './listsalary.component.html',
  styleUrls: ['./listsalary.component.css']
})
export class ListsalaryComponent implements OnInit {
  date: any;
  empName: any;
  listOfEmployees: any;
  employee: any;
  slipdetails: any;
  salary:any;
  constructor(private salaryService: SalaryService,
     private employeeService: EmployeeService,
     private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getEmployees();
  }
  

  public captureScreen()  
  {  
    // var data = document.getElementById('contentToConvert');  
    var data =document.body;
    html2canvas(data!).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 210;   
      var pageHeight = 280;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
     
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('Slip.pdf'); // Generated PDF   
      this.toastr.success("Done!","Downloaded as a pdf");
    });  
  }  

  getSlip() {
    var d = new Date(this.date);
    var month = d.getMonth();
    var year = d.getFullYear();
    month = month + 1;
    var id = parseInt(this.empName);
    
    this.salaryService.getSalary(id, month, year).subscribe(
      data => {
        debugger;
        this.slipdetails = data;
        this.toastr.success("Generated slip!","Done");
      }, error => console.log(error)
    );

    this.salaryService.getAllSalary().subscribe(
      data =>{
        const filters = {
          employee: (employee: { empId: any; }) => employee.empId == id
        };
        debugger;
        var filtered = this.filterArray(data, filters);
       
        this.salary = filtered;
      },error => console.log(error)
    );

    this.getEmployeeDetailsById(id);
  }


  getEmployeeDetailsById(id: any) {
    this.employeeService.getEmployeesById(id).subscribe(
      data => {
        debugger;
        this.employee = data;
      }, error => console.log(error)
    );

  }


  getEmployees() {
    this.employeeService.getEmployeesList().subscribe(data => {
      this.listOfEmployees = data;
    })
  }

    
  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }
}
