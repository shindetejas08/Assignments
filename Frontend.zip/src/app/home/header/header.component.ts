import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router:Router, private authservice :AuthService) { }

  ngOnInit(): void {
    
  }

  logout(){
    if(confirm("Are you sure you want to logout?")){
      localStorage.removeItem("hrid");
      this.router.navigate(['login']);
    }
    else{
      return;
    }
  }

}
