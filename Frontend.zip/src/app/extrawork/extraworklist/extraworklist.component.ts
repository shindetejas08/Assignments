import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExtraworkService } from '../extrawork.service';

@Component({
  selector: 'app-extraworklist',
  templateUrl: './extraworklist.component.html',
  styleUrls: ['./extraworklist.component.css']
})
export class ExtraworklistComponent implements OnInit {
  workList:any;
  constructor(private extraworkservice : ExtraworkService,private router: Router) { }

  ngOnInit(): void {
    this.getWork();
  }

  addwork(){
    this.router.navigate(['addextrawork']);
  }

  getWork(){
    this.extraworkservice.getExtraWork().subscribe(
      response => {
        this.workList = response;
      },error => console.log(error)
    );
  }

}
