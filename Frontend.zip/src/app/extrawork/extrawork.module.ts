import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AddextraworkComponent } from "./addextrawork/addextrawork.component";
import { ExtraworklistComponent } from "./extraworklist/extraworklist.component";
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    declarations: [ExtraworklistComponent,AddextraworkComponent],
    imports: [
      CommonModule,
      FormsModule,
      RouterModule,
      HttpClientModule,
      BrowserModule,
      BrowserAnimationsModule,
      BsDatepickerModule.forRoot(),
    ],
    exports:[
        AddextraworkComponent,
        ExtraworklistComponent
    ]
  })
  export class ExtraworkModule { }