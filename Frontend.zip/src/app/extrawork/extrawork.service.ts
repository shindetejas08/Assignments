import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExtraworkService {
  url="http://localhost:8080/extrawork";
  constructor(private httpClient: HttpClient) { }

  getExtraWork():Observable<any>{
    return this.httpClient.get(this.url);
  }

  addExtraWork(data:any):Observable<any>{
    return this.httpClient.post<any>(this.url+"/addextrawork",data);
  }
}
