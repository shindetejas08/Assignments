import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from 'src/app/employee/employee.service';
import { ExtraworkService } from '../extrawork.service';

@Component({
  selector: 'app-addextrawork',
  templateUrl: './addextrawork.component.html',
  styleUrls: ['./addextrawork.component.css']
})
export class AddextraworkComponent implements OnInit {
  employees: any;

  empName: any;
  costperday: any;
  date: any;

  constructor(private employeeService: EmployeeService,
     private extraworkservice : ExtraworkService,
     private router: Router,
     private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getEmployees();
  }

  addExtraWork() {
    var d = new Date(this.date);
    var day = d.getDate();
    var month = d.getMonth();
    var year = d.getFullYear();
    month = month + 1

    var obj = {
      "employee": {
        "empId": parseInt(this.empName)
      },
      "costPerDay": this.costperday,
      "month": month,
      "day": day,
      "year": year
    }

    this.extraworkservice.addExtraWork(obj).subscribe(
      response =>{
        console.log(response);
        debugger;
        this.router.navigate(['listextrawork']);
        this.toastr.success("Done!","Added extra work");
      },
      error => {
        console.log(error);
        this.toastr.error("Failed!","try again");
      }
    );

  }

  getEmployees() {
    this.employeeService.getEmployeesList().subscribe(data => {
      this.employees = data;
    })
  }
}
