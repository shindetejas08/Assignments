import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentlistComponent } from './departmentlist/departmentlist.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AddnewdepartmentComponent } from './addnewdepartment/addnewdepartment.component';



@NgModule({
  declarations: [DepartmentlistComponent, AddnewdepartmentComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    BrowserModule
  ],
  exports:[
    DepartmentlistComponent,
    AddnewdepartmentComponent
  ]
})
export class DepartmentModule { }
