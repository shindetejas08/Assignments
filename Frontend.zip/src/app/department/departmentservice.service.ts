import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Department } from '../models/department.model';


@Injectable({
  providedIn: 'root'
})
export class DepartmentserviceService {
  private baseUrl = 'http://localhost:8080/department';
  
  constructor(private httpClient: HttpClient) { }

  getAllDepartment():Observable<Department[]>{
    return this.httpClient.get<Department[]>(`${this.baseUrl}`);

  }

  addDepartmentRemote(department:Department):Observable<Department>{
    return this.httpClient.post<Department>(`${this.baseUrl}`,department);
  }
}
