import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Department } from 'src/app/models/department.model';
import { DepartmentserviceService } from '../departmentservice.service';

@Component({
  selector: 'app-departmentlist',
  templateUrl: './departmentlist.component.html',
  styleUrls: ['./departmentlist.component.css']
})
export class DepartmentlistComponent implements OnInit {

  public departments!:Department[];

  constructor(private deptservice: DepartmentserviceService,
                private router: Router) { }

  ngOnInit(): void {
    this.getDepartments();
  }

  getDepartments(){
    this.deptservice.getAllDepartment().subscribe(data =>  {
        console.log(data);
        this.departments=data;
      })
  }


  addDepartment(){
    this.router.navigate(['addnewdepartment']);
  }

 

 

}
