import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddnewdepartmentComponent } from './addnewdepartment.component';

describe('AddnewdepartmentComponent', () => {
  let component: AddnewdepartmentComponent;
  let fixture: ComponentFixture<AddnewdepartmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddnewdepartmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddnewdepartmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
