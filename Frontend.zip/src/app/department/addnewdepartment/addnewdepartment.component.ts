import { Component, OnInit } from '@angular/core';
import { DepartmentserviceService } from '../departmentservice.service';
import { Department } from 'src/app/models/department.model';
import { Router } from '@angular/router'
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-addnewdepartment',
  templateUrl: './addnewdepartment.component.html',
  styleUrls: ['./addnewdepartment.component.css']
})
export class AddnewdepartmentComponent implements OnInit {
  department: Department = new Department;

  constructor(private router: Router, private service: DepartmentserviceService, private toastr: ToastrService) { }

  ngOnInit(): void {
  }

  addDepartmentFormSubmit() {
    this.service.addDepartmentRemote(this.department).subscribe(data => {
      console.log(data);
      this.toastr.success("Done!", "Added Department");
      this.goToList();
    }, error => this.toastr.error(error, "Try again")
    )
  }

  goToList() {
    this.router.navigate(['/departments']);
  }

}
