import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Grade } from 'src/app/models/grade.model';

@Injectable({
  providedIn: 'root'
})
export class GradeserviceService {
  private baseUrl = 'http://localhost:8080/grade';

  constructor(private httpClient : HttpClient) { }

  getAllGrades():Observable<Grade[]>{
      return this.httpClient.get<Grade[]>(`${this.baseUrl}`);
  }

  addGradeRemote(data:any):Observable<any>{
    return this.httpClient.post<any>(`${this.baseUrl}/addgrade`,data);
  }
}
