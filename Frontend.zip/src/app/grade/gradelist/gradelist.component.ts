import { Component, OnInit } from '@angular/core';
import { Grade } from 'src/app/models/grade.model';
import { GradeserviceService } from '../gradeservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gradelist',
  templateUrl: './gradelist.component.html',
  styleUrls: ['./gradelist.component.css']
})
export class GradelistComponent implements OnInit {
  public gradeobj !: Grade[];

  constructor(private gservice : GradeserviceService,
    private router: Router) { }

  ngOnInit(): void {
    this.getGrades();
  }

  getGrades(){
    this.gservice.getAllGrades().subscribe(data =>  {
        console.log(data);
        this.gradeobj=data;
      })
  }

  addGrade(){
    
    this.router.navigate(['addgrade']);
  }

}
