import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GradelistComponent } from './gradelist/gradelist.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { Grade } from '../models/grade.model';
import { GradeserviceService } from './gradeservice.service';
import { AddgradeComponent } from './addgrade/addgrade.component';



@NgModule({
  declarations: [GradelistComponent, AddgradeComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    BrowserModule 
  
  ],
  exports:[
    GradelistComponent,
    AddgradeComponent
  ],
providers:[
 GradeserviceService
]
})
export class GradeModule { }
