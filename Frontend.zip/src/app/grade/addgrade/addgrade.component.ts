import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Grade } from 'src/app/models/grade.model';
import { GradeserviceService } from '../gradeservice.service';

@Component({
  selector: 'app-addgrade',
  templateUrl: './addgrade.component.html',
  styleUrls: ['./addgrade.component.css']
})
export class AddgradeComponent implements OnInit {
  gradeobj: Grade = new Grade();
  GradeName:any;
  basicSal:any;
  medicalallowance:any;
  attendanceAllowance:any;
  perday:any;
  hra:any;
  bonus:any;

  constructor(private router: Router,
    private service: GradeserviceService,
    private toaster: ToastrService) { }

  ngOnInit(): void {
  }

  addGradeFormSubmit() {
    var obj = {
      "bonus": this.bonus,
      "grade": this.GradeName,
      "basicSalary": this.basicSal,
      "medicalAllowance": this.medicalallowance,
      "attendanceAllowance": this.attendanceAllowance,
      "perDay": this.perday,
      "hra": this.hra
    };
    console.log(obj);

    this.service.addGradeRemote(obj).subscribe(
      data => {
        console.log(data);
        this.goToList();
        this.toaster.success("Done!","successfully added grade")
      }, error => console.log(error)
    );
  }

  goToList() {
    this.router.navigate(['/gradelist']);
  }

}
