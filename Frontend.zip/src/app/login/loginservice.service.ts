import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HrLogin} from 'src/app/models/hrLogin.model'
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private httpClient: HttpClient) { }

  loginHrFromRemote(hrlogin :HrLogin):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/hr/login",hrlogin)
  }
}
