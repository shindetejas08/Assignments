import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HrLogin } from 'src/app/models/hrLogin.model';
import { LoginserviceService } from '../loginservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: HrLogin = new HrLogin;

  constructor(private loginservice: LoginserviceService,
    private router: Router,
    private toastr: ToastrService) { }

  ngOnInit(): void {
   
  }
  onsubmit() {

    this.loginservice.loginHrFromRemote(this.login).subscribe(
      data => {
        if (data != null) {
          localStorage.setItem("hrid",data.hrId);
          this.toastr.success('Successfully logged in!', 'Welcome!');
          this.router.navigate(['/employee/emplyeelist']);
          
        }
        else{
          this.toastr.error('Failed to logged in!', 'Invalid Credentials!');
        }
        // this.goToHome();
        console.log(data);
      }, error => {
        console.log(error);
        this.toastr.error('Failed to logged in!', 'Invalid Credentials!');
      }
    );
  }

}

