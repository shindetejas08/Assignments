import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { EmployeeModule } from './employee/employee.module';
import { LoginModule } from './login/login.module';
import { HomeModule } from './home/home.module';
import { ToastrModule } from 'ngx-toastr';
import { DepartmentModule } from './department/department.module' 
import { GradeModule } from './grade/grade.module';
import { ExtraworkModule } from './extrawork/extrawork.module';
import { ListsalaryComponent } from './salary/listsalary/listsalary.component';



@NgModule({
  declarations: [
    AppComponent,
    ListsalaryComponent
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    ToastrModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
    EmployeeModule,
    LoginModule,
    HomeModule,
    DepartmentModule,
    GradeModule,
    ExtraworkModule
   
  
  ],
  exports:[
    
  ],
 
  bootstrap: [AppComponent]
})
export class AppModule { }
